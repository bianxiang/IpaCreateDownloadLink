let isWx = false;
var u = navigator.userAgent;
var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1; //g
var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

var a_mask = document.getElementById('a_mask');
var i_mask = document.getElementById('i_mask');
//window.navigator.userAgent属性包含了浏览器类型、版本、操作系统类型、浏览器引擎类型等信息，这个属性可以用来判断浏览器类型
var ua = window.navigator.userAgent.toLowerCase();
//通过正则表达式匹配ua中是否含有MicroMessenger字符串
if (ua.match(/MicroMessenger/i) == 'micromessenger') {
    isWx = true;
} else {
    isWx = false;
}

function clickDownLoad(type) {
    if (isWx) {
        if (isAndroid) {
            a_mask.style.display = 'block';
        } else {
            i_mask.style.display = 'block';
        }

    } else {
        if (type == 'ios') {
            if (isIOS) {
                window.location.href = 'itms-services://?action=download-manifest&url=https://swapwallet.oss-cn-beijing.aliyuncs.com/App/ios/manifest.plist';
            } else {
                alert('请选择与手机系统相同的安装包版本下载');
            }
        } else {
            if (isAndroid) {
                window.location.href = 'https://swapwallet.oss-cn-beijing.aliyuncs.com/App/android/app-release.apk';

            } else {
                alert('请选择与手机系统相同的安装包版本下载');
            }
        }
    }
}
